/*
-- Query: SELECT * FROM AirBnB.employee
LIMIT 0, 1000

-- Date: 2022-09-18 11:14
*/
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (1,'Peggie','Bechtelar','1-019-451-9861x0725','2012-05-10 00:31:06','1986-06-03 01:30:25',1);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (2,'Meaghan','Walter','1-042-864-8384x77899','1970-12-07 19:02:00','2021-01-18 10:06:09',2);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (3,'Marlin','Eichmann','733.753.4397x21498','2013-12-21 12:25:13','1985-07-05 23:31:20',3);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (4,'Rosella','Hauck','024-976-6827','1988-07-17 15:05:13','2006-02-04 15:00:16',4);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (5,'Orland','Crona','03284385704','2008-05-04 16:41:29','1997-07-23 21:27:27',5);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (6,'Annamarie','Bernier','166-227-3644x93438','1978-02-27 14:24:19','2010-02-11 10:39:53',6);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (7,'Velda','Miller','+16(4)4141538950','2014-06-14 14:31:48','1983-07-11 09:12:42',7);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (8,'Elizabeth','Kunde','533.467.6449','1974-12-26 14:56:09','1994-05-16 06:21:51',8);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (9,'Elvis','Zulauf','582-007-3769','2015-09-24 16:35:47','2010-07-10 06:18:26',9);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (10,'Allene','Pfannerstill','1-715-677-2734','2003-11-30 00:14:27','2014-06-30 13:06:54',10);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (11,'Florence','Bahringer','376.519.5353','1997-07-10 23:07:56','2013-11-29 02:12:31',11);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (12,'Edwina','Parisian','(182)459-4876x173','2021-04-19 17:30:52','2022-08-01 22:29:06',12);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (13,'Axel','Hermiston','1-170-116-5377x6265','2010-01-24 19:59:16','2009-01-02 11:26:38',13);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (14,'Ardith','Ward','1-218-321-4492','1997-06-22 22:53:25','1992-02-08 08:01:11',14);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (15,'Carol','Howell','06232678667','2017-10-25 22:27:17','2000-05-26 09:09:58',15);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (16,'Garnet','Reilly','294-778-5389','2006-03-04 15:00:08','1985-04-01 21:47:46',16);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (17,'Emory','Gorczany','460-288-6980x89027','1985-12-04 03:05:11','2000-03-11 12:03:09',17);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (18,'Ford','Romaguera','(054)371-8644x977','2015-07-17 19:12:03','1973-01-08 08:13:01',18);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (19,'Lucienne','Harvey','129.992.0901','2011-11-20 01:09:07','2016-04-05 11:45:22',19);
INSERT INTO `AirBnB`.`employee` (`id_employee`,`name`,`surname`,`telephone`,`create_time`,`update_time`,`fk_facilityId`) VALUES (20,'Granville','Watsica','01188560304','2009-06-06 00:06:41','1977-12-18 14:37:11',20);
