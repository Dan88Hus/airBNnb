/*
-- Query: select * from `AirBnB`.`userRole`
LIMIT 0, 1000

-- Date: 2022-09-17 17:59
*/
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (1,'host','et','voluptatem','jrolfson@example.org','(606)634-1706x00704','2000-08-25 06:12:13','2004-10-18 04:12:38');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (2,'guest','illo','et','qhettinger@example.com','1-461-894-9228x057','2004-02-18 14:10:57','2003-09-29 00:44:07');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (3,'guest','ipsum','voluptatum','kuhlman.chauncey@example.org','1-610-422-7408x0839','2014-02-24 10:15:18','2002-09-05 07:27:53');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (4,'host','ut','excepturi','tkunze@example.com','05613297942','2012-09-25 06:11:34','2003-10-26 14:37:25');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (5,'guest','ipsa','mollitia','elna.schmidt@example.com','(539)821-9049','1994-06-24 03:20:30','1984-11-15 10:30:24');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (6,'guest','ipsa','sed','linnie.predovic@example.net','759-965-8281x76493','1977-08-21 16:20:34','1984-02-07 05:11:00');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (7,'host','vitae','nemo','russ13@example.com','104-108-1135x571','1999-05-13 17:26:32','2012-09-01 12:15:36');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (8,'guest','nemo','autem','kutch.idella@example.org','048-507-3214','1972-10-10 08:05:03','1982-06-21 16:52:14');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (9,'host','vel','consequatur','caden.christiansen@example.com','1-013-918-5587x037','2007-11-05 14:06:05','1996-03-27 23:37:45');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (10,'guest','optio','dolores','marina.treutel@example.com','827-284-9158x4761','2005-04-13 17:43:12','2013-10-29 11:25:55');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (11,'guest','sed','hic','hartmann.mitchel@example.org','(023)260-8363x78757','1995-07-18 22:15:37','1976-06-06 17:43:46');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (12,'host','dolore','exercitationem','kris.heber@example.org','835-878-5031x5977','1989-09-05 12:35:03','2008-03-12 20:50:38');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (13,'guest','eos','reiciendis','jpagac@example.org','112-504-7617','1987-03-11 04:10:12','2021-10-12 03:55:19');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (14,'guest','et','sed','asa.eichmann@example.org','889.799.5273x53418','2009-08-28 13:20:33','2015-11-25 20:11:01');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (15,'guest','quia','eaque','vanessa.heathcote@example.org','1-491-032-2376','1995-10-15 00:00:41','1974-07-25 06:06:19');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (16,'guest','ipsa','delectus','bweber@example.com','1-672-385-8697x7764','2018-06-19 03:28:13','1998-06-13 05:49:12');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (17,'host','quo','voluptatem','terrill81@example.net','1-307-805-2666x69731','2001-09-16 23:09:05','1995-05-19 00:13:57');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (18,'guest','enim','temporibus','mosciski.marcelino@example.org','01524203529','2010-09-19 08:49:07','1994-02-22 03:52:32');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (19,'guest','assumenda','tempora','schimmel.gilberto@example.org','656-302-6469x792','1981-05-28 18:45:57','2006-09-15 08:07:54');
INSERT INTO `AirBnB`.`userRole` (`id_userRole`,`userRole`,`name`,`surname`,`email`,`telephone`,`create_time`,`update_time`) VALUES (20,'host','qui','dolorem','parisian.gail@example.com','086.349.7159','1982-06-01 00:22:50','2006-12-12 06:19:49');
