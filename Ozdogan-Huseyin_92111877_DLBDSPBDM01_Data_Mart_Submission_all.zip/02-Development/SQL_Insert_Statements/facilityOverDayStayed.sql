/*
-- Query: SELECT * FROM AirBnB.facilityOverDayStayed
LIMIT 0, 1000

-- Date: 2022-09-18 07:59
*/
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (1,8,'1998-08-16 21:29:21','2008-11-17 08:46:25',1);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (2,7,'1982-01-07 11:34:16','2007-02-25 20:35:14',2);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (3,3,'1980-06-08 19:22:42','2013-05-01 07:02:13',3);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (4,2,'1995-10-23 10:14:17','2016-11-29 03:46:56',4);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (5,3,'1975-09-07 10:45:12','1986-11-08 18:46:35',5);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (6,0,'1998-05-16 13:21:06','1999-04-30 15:12:07',6);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (7,3,'1988-08-15 22:32:16','2002-11-13 05:21:25',7);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (8,2,'2020-12-09 16:15:34','1979-11-09 01:06:44',8);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (9,5,'1971-03-02 07:46:17','2020-06-11 10:37:40',9);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (10,0,'1981-09-06 20:48:46','1976-01-30 16:46:47',10);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (11,4,'1975-01-22 09:51:58','1971-04-29 19:26:21',11);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (12,1,'1995-09-20 15:19:08','1973-06-11 17:50:50',12);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (13,4,'1973-07-15 12:33:42','2010-12-16 12:56:34',13);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (14,6,'1990-11-19 19:45:56','2015-05-30 16:42:16',14);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (15,2,'1976-12-02 11:58:30','2020-09-23 20:38:58',15);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (16,6,'1971-06-22 17:59:59','1998-07-24 12:21:09',16);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (17,2,'2003-05-11 15:37:00','1985-01-03 03:40:30',17);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (18,5,'2002-03-08 15:58:23','2019-04-28 17:30:57',18);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (19,0,'2003-09-09 04:25:55','1983-11-05 11:00:01',19);
INSERT INTO `AirBnB`.`facilityOverDayStayed` (`id_facilityOverDayStayed`,`overDays`,`create_time`,`update_time`,`fk_facilityId`) VALUES (20,2,'2012-02-09 13:30:29','1987-04-02 22:30:58',20);
