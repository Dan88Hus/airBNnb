/*
-- Query: select * from `AirBnB`.`facilityPrice`
LIMIT 0, 1000

-- Date: 2022-09-17 19:42
*/
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (1,5,'1998-05-17 20:00:03','1971-05-19 03:36:45',1);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (2,2,'2007-12-07 07:23:10','1997-10-16 01:30:57',2);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (3,4,'2010-03-30 02:54:22','2000-06-09 00:30:37',3);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (4,3,'2014-09-10 20:07:48','1978-03-14 11:56:58',4);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (5,2,'1978-01-25 19:46:51','1998-09-19 00:45:02',5);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (6,1,'1992-02-23 02:48:13','1991-01-23 21:01:46',6);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (7,4,'1979-02-16 14:41:48','1987-04-14 07:03:52',7);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (8,7,'2011-01-24 18:23:10','1993-12-20 06:18:23',8);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (9,2,'1999-07-06 15:21:05','2017-05-04 01:50:31',9);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (10,3,'2018-03-19 06:29:05','1979-11-02 05:28:33',10);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (11,1,'1980-07-18 05:34:47','1994-08-13 03:35:31',11);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (12,1,'1992-01-08 14:13:51','1974-12-24 10:07:13',12);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (13,3,'1995-08-06 16:42:36','2014-07-07 08:09:43',13);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (14,2,'1985-01-09 23:10:00','2009-11-18 02:33:05',14);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (15,7,'1979-06-08 02:27:56','2020-09-30 16:05:56',15);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (16,9,'2009-01-23 15:38:58','2013-03-21 21:41:22',16);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (17,5,'1970-04-01 15:34:05','2003-07-17 02:11:44',17);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (18,3,'2003-12-02 03:07:25','2020-03-06 00:52:00',18);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (19,2,'1989-05-18 07:36:51','1982-04-15 15:38:51',19);
INSERT INTO `AirBnB`.`facilityPrice` (`id_facilityPrice`,`pricePerDay`,`create_time`,`update_time`,`fk_facilityId`) VALUES (20,9,'2022-03-06 02:01:15','1976-01-15 17:28:45',20);
