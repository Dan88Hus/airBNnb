/*
-- Query: SELECT * FROM AirBnB.userTaxId
LIMIT 0, 1000

-- Date: 2022-09-18 10:17
*/
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (1,'90874-8312','2012-01-15 13:43:00','1997-12-31 05:12:11',1);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (2,'38742','1989-09-06 11:18:00','2003-10-19 11:20:19',2);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (3,'01989','2003-01-27 20:15:15','2014-05-11 20:32:12',3);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (4,'12757','1992-12-28 04:31:14','1979-05-25 03:23:47',4);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (5,'51590','2013-11-22 07:02:31','1973-10-21 12:23:58',5);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (6,'99400-7219','1997-09-23 01:20:52','2007-10-20 09:08:51',6);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (7,'48639','1982-03-01 10:24:10','1976-07-15 08:08:32',7);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (8,'18234-2569','1985-08-21 17:22:01','1977-06-05 07:25:40',8);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (9,'29800','2000-09-09 01:33:46','1996-12-22 11:36:17',9);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (10,'63648-9182','1987-08-02 05:00:09','1992-10-25 14:06:20',10);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (11,'78238-2670','2003-04-26 11:28:42','2019-08-11 07:39:37',11);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (12,'82044-6421','1991-09-01 13:37:01','2000-11-24 14:05:06',12);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (13,'66884','2002-04-24 13:13:56','1977-04-06 13:27:41',13);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (14,'66186','1976-05-06 01:16:56','1997-01-20 20:00:11',14);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (15,'97872-7923','2008-08-12 13:06:13','1980-06-12 16:05:42',15);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (16,'37555-2247','2003-08-30 16:23:43','1987-11-21 22:54:22',16);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (17,'94883-5564','2018-12-22 12:26:16','2000-01-10 02:00:15',17);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (18,'31385','2012-08-19 21:30:42','2003-03-02 08:58:34',18);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (19,'20760','1974-11-24 07:19:24','2011-11-26 02:07:50',19);
INSERT INTO `AirBnB`.`userTaxId` (`id_userTaxId`,`userTaxNo`,`create_time`,`update_time`,`fk_userRoleId`) VALUES (20,'88349-8975','1977-06-01 10:09:48','1983-07-09 19:42:20',20);
