/*
-- Query: SELECT * FROM AirBnB.expectedIncome
LIMIT 0, 1000

-- Date: 2022-09-18 14:44
*/
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (1,4558,'1986-05-14 16:31:53','1979-05-22 08:51:45',1,1,1);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (2,2325,'2003-11-09 02:00:56','2020-06-16 19:22:50',2,2,2);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (3,5947,'1977-04-26 19:36:07','1977-10-01 17:11:27',3,3,3);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (4,3332,'1983-04-05 08:43:58','2016-07-06 23:17:00',4,4,4);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (5,513,'1989-08-09 13:23:46','1986-12-14 00:35:56',5,5,5);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (6,5668,'1977-10-16 18:51:09','1997-03-17 15:37:35',6,6,6);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (7,5741,'2002-11-23 10:45:41','2018-04-25 00:30:32',7,7,7);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (8,1604,'1970-07-11 11:22:09','1980-12-25 07:57:43',8,8,8);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (9,846,'1991-02-08 12:52:58','1973-10-23 15:07:08',9,9,9);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (10,2534,'2004-02-18 14:42:40','1989-07-10 00:35:02',10,10,10);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (11,3935,'2005-10-14 10:37:23','1990-06-27 23:53:37',11,11,11);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (12,1568,'1983-04-21 21:07:43','1977-09-25 19:18:01',12,12,12);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (13,4924,'1987-11-04 17:31:23','2021-07-04 22:21:17',13,13,13);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (14,2939,'1973-06-21 09:49:57','1994-07-11 11:02:17',14,14,14);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (15,2444,'2010-08-24 11:52:20','1979-09-23 23:02:41',15,15,15);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (16,1863,'2009-04-27 13:42:39','2017-12-18 22:45:14',16,16,16);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (17,4295,'1997-12-10 06:11:26','1994-10-09 10:44:51',17,17,17);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (18,4003,'1979-02-26 17:09:07','1996-01-27 14:07:58',18,18,18);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (19,5662,'1974-12-10 00:31:55','2012-04-08 08:07:36',19,19,19);
INSERT INTO `AirBnB`.`expectedIncome` (`id_expectedIncome`,`expectedIncome`,`create_time`,`update_time`,`fk_facilityId`,`fk_facilityPriceId`,`fk_facilityOrderId`) VALUES (20,2765,'1980-04-11 17:11:58','2008-05-09 14:46:38',20,20,20);
