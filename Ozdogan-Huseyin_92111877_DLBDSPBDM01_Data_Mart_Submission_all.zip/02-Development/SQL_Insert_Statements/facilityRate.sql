/*
-- Query: select * from `AirBnB`.`facilityRate`
LIMIT 0, 1000

-- Date: 2022-09-17 19:10
*/
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (1,3,'2008-06-28 09:32:51','1973-01-02 22:15:27',1,1);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (2,5,'1975-03-21 18:07:49','1975-04-05 07:21:06',2,2);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (3,4,'1976-10-22 13:34:03','1997-08-01 22:48:35',3,3);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (4,1,'1998-06-05 04:20:04','1981-06-24 03:15:51',4,4);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (5,5,'2005-06-02 20:01:16','1978-06-15 14:44:10',5,5);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (6,3,'1993-06-23 06:04:16','1985-06-07 00:23:10',6,6);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (7,5,'2000-04-06 10:02:39','2021-12-08 23:31:22',7,7);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (8,5,'1998-10-25 04:10:38','1991-07-23 00:49:24',8,8);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (9,3,'1989-08-21 02:37:29','1974-11-19 02:40:48',9,9);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (10,4,'2012-07-31 13:44:27','1999-09-04 06:48:56',10,10);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (11,3,'1989-08-30 15:55:51','2011-06-30 13:14:40',11,11);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (12,4,'2002-11-18 13:44:14','2004-09-04 19:43:30',12,12);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (13,3,'2022-06-27 12:45:17','1987-04-23 13:05:25',13,13);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (14,1,'2002-11-01 09:13:44','1989-05-02 02:42:03',14,14);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (15,5,'1974-05-12 18:51:49','1979-06-23 03:36:57',15,15);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (16,4,'1970-12-03 22:58:10','2011-08-17 02:16:56',16,16);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (17,2,'1972-08-10 21:54:27','1973-08-15 12:30:21',17,17);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (18,5,'2000-09-25 14:58:28','1989-09-20 19:28:29',18,18);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (19,1,'1987-07-29 10:29:54','1977-07-23 10:16:31',19,19);
INSERT INTO `AirBnB`.`facilityRate` (`id_facilityRate`,`rate`,`create_time`,`update_time`,`fk_userRole`,`fk_facilityId`) VALUES (20,4,'2011-01-31 22:10:37','2014-04-04 05:16:41',20,20);
